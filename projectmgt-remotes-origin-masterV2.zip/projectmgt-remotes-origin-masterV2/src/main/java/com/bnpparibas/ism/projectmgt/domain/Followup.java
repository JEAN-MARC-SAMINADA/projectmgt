package com.bnpparibas.ism.projectmgt.domain;

public enum Followup {
    STANDARD,
    LIGHT,
    ENFORCED,
}
